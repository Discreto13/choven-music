
#!/bin/bash

# Затримка, щоб дочекатися повного запуску Volumio
echo "[resume] Waiting for Volumio startup..."
until curl -s http://localhost:3000/api/v1/getState >/dev/null; do
    sleep 3
done
sleep 5

echo "[resume] Volumio is up, proceeding with state restoration"

STATE_FILE="/data/volumio_last_state.json"

# Перевіряємо, чи існує файл стану
if [ ! -f "$STATE_FILE" ]; then
    echo "[resume] No saved state found."
    exit 0
fi

URI=$(jq -r .uri "$STATE_FILE")
POSITION=$(jq -r .seek "$STATE_FILE")
VOLUME=$(jq -r .volume "$STATE_FILE")

if [ "$URI" == "null" ] || [ "$URI" == "" ]; then
    echo "[resume] No URI found in state file."
    exit 0
fi

# Встановлюємо гучність
curl -s "http://localhost:3000/api/v1/commands/?cmd=setVolume&volume=$VOLUME"

# Відтворюємо трек
curl -s -X POST "http://localhost:3000/api/v1/commands/?cmd=play&uri=$URI"
sleep 2

# Перемотка до позиції
curl -s -X POST "http://localhost:3000/api/v1/seek?position=$POSITION"

echo "[resume] State restored: $URI at $POSITION ms, volume $VOLUME"
