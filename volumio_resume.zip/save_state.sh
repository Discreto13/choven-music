
#!/bin/bash

# Цей скрипт слід запускати раз на хвилину через cron
STATE_FILE="/data/volumio_last_state.json"
curl -s http://localhost:3000/api/v1/getState -o "$STATE_FILE"
